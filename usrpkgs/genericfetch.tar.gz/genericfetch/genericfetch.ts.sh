#!/bin/sh

touch /var/log/glacier/genericfetch.timestamp
date >> /var/log/glacier/genericfetch.timestamp
