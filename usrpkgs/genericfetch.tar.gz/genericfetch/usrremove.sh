#!/bin/sh

rm /usr/bin/genericfetch
rm /var/log/glacier/genericfetch.sh
rm /etc/glacier/pkginfo/genericfetch-pkginfo.json
