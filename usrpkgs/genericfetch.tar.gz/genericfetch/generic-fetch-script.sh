#!/bin/sh
# generic fetch script because im bored

printf "USR - $USER\n"
printf "DE - $XDG_CURRENT_DESKTOP\n"
printf "SH - $SHELL\n"
printf "\n"
printf "you should probably go outside\n"
