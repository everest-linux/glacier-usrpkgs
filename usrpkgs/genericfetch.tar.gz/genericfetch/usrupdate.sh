#!/bin/sh

rm /usr/bin/genericfetch
rm /var/log/glacier/genericfetch.timestamp
cp generic-fetch-script.sh genericfetch
chmod +x genericfetch
mv genericfetch /usr/bin
./genericfetch.ts.sh
