#!/bin/sh

cp generic-fetch-script.sh genericfetch
chmod +x genericfetch
chmod +x genericfetch.ts.sh
mv genericfetch /usr/bin
mv genericfetch-pkginfo.json /etc/glacier/pkginfo
./genericfetch.ts.sh
